package com.example.zheey.kilasi;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.support.v7.app.ActionBar;

/**
 * Created by zainny on 23/08/2015.
 */
    abstract class TabListener implements ActionBar.TabListener{
        private Fragment fragment;

        public TabListener(Fragment fragment){
            this.fragment = fragment;
        }
        public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft){
            ft.add(R.id.fragment_placeholder, fragment, null);
        }
        public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {
        }
        public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {
            ft.remove(fragment);
        }
    }

